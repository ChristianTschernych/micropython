import uasyncio as asyncio
from mqtt_as import MQTTClient
from mqtt_as import config


SERVER = '192.168.0.108'  # Change to suit e.g. 'iot.eclipse.org'

def boring(s):
    print("Blowing air!")

mode = None
current = None

def callback(topic, msg, retained):
    print((topic, msg, retained))
    print(str(msg))

    if msg.decode("utf-8") is "rainbow":
        global mode
        mode = rainbow
        print("Led switched to rainbow")
    elif msg.decode("utf-8") is "off":
        global mode
        mode = off
        print("Led switched to off")
    elif msg.decode("utf-8") is "on":
        global mode
        mode = one_color
        print("Led switched to on")

async def conn_han(client):
    await client.subscribe('chris/led', 1)




###MAIN
async def main(client, strip):
    
    await client.connect()
    n = 0
    while True:
        global mode
        await asyncio.sleep(5)
        #print('publish', n)
        ## If WiFi is down the following will pause for the duration.
        #await client.publish('result', '{}'.format(n), qos = 1)
        #n += 1
        #print(mode)
        if mode is not None:
            task = asyncio.create_task(mode(strip))
            await task

            #asyncio.run(mode(strip))
            #print("Trying to run")









config['subs_cb'] = callback
config['connect_coro'] = conn_han
config['server'] = SERVER
print("got here")

MQTTClient.DEBUG = True  # Optional: print diagnostic messages
client = MQTTClient(config)

print("got here")
#LED Init

import neopixel
import machine

NUM_LEDS = 600
DATA_PIN = 5

strip = neopixel.NeoPixel(machine.Pin(DATA_PIN), NUM_LEDS)

async def off(strip):
    global current
    global mode

    current = off
    print("LED is ", current)

    n = int(NUM_LEDS/2)
    r = range(n)
    sw = strip.write

    for i in r:
        strip[i] = (0, 0, 0)
        strip[NUM_LEDS-i-1] = (0, 0, 0)
        sw()

    current = None
    mode = None

async def one_color(strip, val = (31,36,181)):
    global current
    global mode

    current = one_color
    print("LED is ", current)

    n = int(NUM_LEDS/2)
    r = range(n)
    sw = strip.write

    for i in r:
        strip[i] = val
        strip[NUM_LEDS-i-1] = val
        sw()

    current = None
    mode = None

async def rainbow(strip):
    print("Im alive")
    global current 
    global mode

    current = rainbow
    print("LED is ", current)

    w = wheel
    rj = range(256)
    ri = range(NUM_LEDS)
    sr = strip.write
    res = 0
    while True:
        for j in rj:
            await asyncio.sleep(.5)
            print("running")
            sr()

            if current is not mode:
                print("Turn off rainbow")
                return 0
            for i in ri:
                strip[i] = w((i + j) & 255)
        
       

        
                


def wheel(offset = 0):
    # The colours are a transition r - g - b - back to r
    offset = 255 - offset
    if offset < 85:
        return (255 - offset * 3, 0, offset * 3)
    if offset < 170:
        offset -= 85
        return (0, offset * 3, 255 - offset * 3)
    offset -= 170
    return (offset * 3, 255 - offset * 3, 0,)   


#loop

strip[300] = (250,250,250)
strip[0] = (250,250,250)
strip.write()

try:
    asyncio.run(main(client, strip))
finally:
    client.close()  # Prevent LmacRxBlk:1 errors
